import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from scipy.stats import kruskal

# Load the CSV file
file_path = 'IER_Fitbit_Data_2024.csv'
data = pd.read_csv(file_path, encoding='latin1')

# Function to calculate the average Vigorous MET minutes per week for a specific year
def avg_vigorous_met_for_year(data, year):
    data_year = data[data['year'] == year].copy()
    data_year[['tijd_zwa1_uur', 'tijd_zwa1_min', 'dag_zwa1']] = data_year[['tijd_zwa1_uur', 'tijd_zwa1_min', 'dag_zwa1']].fillna(0)
    data_year['Vigorous_MET_minutes_per_week_1'] = 8 * ((data_year['tijd_zwa1_uur'] * 60 + data_year['tijd_zwa1_min']) * data_year['dag_zwa1'])
    data_year[['tijd_zwa2_uur', 'tijd_zwa2_min', 'dag_zwa2']] = data_year[['tijd_zwa2_uur', 'tijd_zwa2_min', 'dag_zwa2']].fillna(0)
    data_year['Vigorous_MET_minutes_per_week_2'] = 8 * ((data_year['tijd_zwa2_uur'] * 60 + data_year['tijd_zwa2_min']) * data_year['dag_zwa2'])
    data_year['Avg_Vigorous_MET_minutes_per_week'] = (data_year['Vigorous_MET_minutes_per_week_1'] + data_year['Vigorous_MET_minutes_per_week_2']) / 2
    return data_year['Avg_Vigorous_MET_minutes_per_week']

# List of years to process
years = [2019, 2020, 2021, 2022, 2023]

# DataFrame to store the data
data_boxplot = pd.DataFrame()

# Collect data for each year and append to the DataFrame
for year in years:
    avg_vigorous_met = avg_vigorous_met_for_year(data, year)
    year_data = pd.DataFrame({'Year': year, 'Avg_Vigorous_MET_minutes_per_week': avg_vigorous_met})
    data_boxplot = pd.concat([data_boxplot, year_data], ignore_index=True)

# Perform the Kruskal-Wallis H Test
data_lists = [data_boxplot[data_boxplot['Year'] == year]['Avg_Vigorous_MET_minutes_per_week'].values for year in years]
stat, p = kruskal(*data_lists)

print(f'Kruskal-Wallis H Test statistic: {stat}')
print(f'p-value: {p}')

# Interpretation
alpha = 0.05
if p < alpha:
    print("There is a significant difference between the groups.")
else:
    print("There is no significant difference between the groups.")

# Calculate means and standard deviations
means = data_boxplot.groupby('Year')['Avg_Vigorous_MET_minutes_per_week'].mean()
std_devs = data_boxplot.groupby('Year')['Avg_Vigorous_MET_minutes_per_week'].std()

# Calculate standard deviation as a percentage of the mean
std_devs_percent = (std_devs / means) * 100

print("Means:")
print(means)
print("Standard Deviations (%):")
print(std_devs_percent)

# Plot the box plot
plt.figure(figsize=(12, 8))
sns.boxplot(x='Year', y='Avg_Vigorous_MET_minutes_per_week', data=data_boxplot)
plt.title('Distribution of Vigorous MET Minutes Per Week Across Years', fontsize=28)
plt.xlabel('Year', fontsize=24)
plt.ylabel('Vigorous MET Minutes Per Week', fontsize=24)
plt.xticks(fontsize=20)
plt.yticks(fontsize=20)
plt.grid(True)
plt.show()
